# inference.py
import joblib
import numpy as np

def model_fn(model_dir):
    """Load the model for inference"""
    model = joblib.load(f"{model_dir}/random_forest_model.pkl")
    return model

def input_fn(request_body, request_content_type):
    """Preprocess the request input"""
    if request_content_type == "text/csv":
        return np.array(request_body.split(",")).reshape(1, -1)
    else:
        raise ValueError("Unsupported content type: {}".format(request_content_type))

def predict_fn(input_data, model):
    """Make a prediction"""
    return model.predict(input_data)

def output_fn(prediction, response_content_type):
    """Format the prediction output"""
    return str(prediction[0])
